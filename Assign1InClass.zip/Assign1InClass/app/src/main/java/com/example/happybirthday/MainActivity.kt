package com.example.happybirthday

import com.example.happybirthday.R
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var editTextNumber: EditText
    private lateinit var radioButtonEven: RadioButton
    private lateinit var radioButtonOdd: RadioButton
    private lateinit var radioButtonSquare: RadioButton
    private lateinit var radioButtonToggle: RadioButton
    private lateinit var listView: ListView
    private lateinit var textView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        editTextNumber = findViewById(R.id.editTextNumber)
        radioButtonEven = findViewById(R.id.radioButton)
        radioButtonOdd = findViewById(R.id.radioButton2)
        radioButtonSquare = findViewById(R.id.radioButton3)
        radioButtonToggle = findViewById(R.id.radioButton4)
        listView = findViewById(R.id.listView)
        textView = findViewById(R.id.textView)

        // Xử lý khi bấm vào nút radioButtonToggle
        radioButtonToggle.setOnClickListener {
            if (listView.visibility == View.VISIBLE) {
                listView.visibility = View.GONE
            } else {
                listView.visibility = View.VISIBLE
            }
        }

        // Kiểm tra số và hiển thị danh sách khi nhấn các RadioButton
        val options = arrayListOf<String>()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, options)
        listView.adapter = adapter

        val updateList: () -> Unit = {
            options.clear()
            val input = editTextNumber.text.toString()
            if (input.isEmpty() || !isNumeric(input)) {
                textView.text = "Vui lòng nhập lại!"}
            else {
                textView.text = ""
                val number = input.toInt()
                options.addAll(generateList(number))
                adapter.notifyDataSetChanged()
            }
        }

        radioButtonEven.setOnClickListener { updateList() }
        radioButtonOdd.setOnClickListener { updateList() }
        radioButtonSquare.setOnClickListener { updateList() }
    }

    // Tạo danh sách dựa trên lựa chọn RadioButton
    private fun generateList(number: Int): List<String> {
        val list = mutableListOf<String>()
        for (i in 1..number) {
            when {
                radioButtonEven.isChecked && i % 2 == 0 -> list.add("$i là số chẵn")
                radioButtonOdd.isChecked && i % 2 != 0 -> list.add("$i là số lẻ")
                radioButtonSquare.isChecked && isPerfectSquare(i) -> list.add("$i là số chính phương")
            }
        }
        return list
    }

    // Kiểm tra xem một số có phải là số chính phương không
    private fun isPerfectSquare(n: Int): Boolean {
        val sqrt = kotlin.math.sqrt(n.toDouble()).toInt()
        return sqrt * sqrt == n
    }

    fun isNumeric(input: String): Boolean {
        return input.toIntOrNull() != null
    }
}
